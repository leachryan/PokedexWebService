﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;

namespace Pokedex_Web_Service
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the interface name "IService1" in both code and config file together.
    [ServiceContract]
    public interface IPokdexRESTJSON
    {
        //add operation contracts for methods
        [OperationContract]
        [WebGet(ResponseFormat = WebMessageFormat.Json, UriTemplate = "getName/{currentIndex}")]
        string getName(string currentIndex);

        [OperationContract]
        [WebGet(ResponseFormat = WebMessageFormat.Json, UriTemplate = "getMaxIndex/")]
        string getMaxIndex();

        [OperationContract]
        [WebGet(ResponseFormat = WebMessageFormat.Json, UriTemplate = "getType1/{currentIndex}")]
        string getType1(string currentIndex);

        [OperationContract]
        [WebGet(ResponseFormat = WebMessageFormat.Json, UriTemplate = "getType2/{currentIndex}")]
        string getType2(string currentIndex);

        [OperationContract]
        [WebGet(ResponseFormat = WebMessageFormat.Json, UriTemplate = "getFlavorText/{currentIndex}")]
        string getFlavorText(string currentIndex);

        [OperationContract]
        [WebGet(ResponseFormat = WebMessageFormat.Json, UriTemplate = "search/{searchCriteria}")]
        string search(string searchCriteria);

        [OperationContract]
        [WebGet(ResponseFormat = WebMessageFormat.Json, UriTemplate = "type1Query/{selectedType}")]
        List<string> type1Query(string selectedType);
        
        //the following four operation contracts are not done
        [OperationContract]
        [WebGet(ResponseFormat = WebMessageFormat.Json, UriTemplate = "getMegaTypes/{currentIndex}")]
        string getMegaTypes(string currentIndex);

        [OperationContract]
        [WebGet(ResponseFormat = WebMessageFormat.Json, UriTemplate = "getMegaXTypes/{currentIndex}")]
        string getMegaXTypes(string currentIndex);

        [OperationContract]
        [WebGet(ResponseFormat = WebMessageFormat.Json, UriTemplate = "getMegaYTypes/{currentIndex}")]
        string getMegaYTypes(string currentIndex);

        [OperationContract]
        [WebGet(ResponseFormat = WebMessageFormat.Json, UriTemplate = "getPrimalTypes/{currentIndex}")]
        string getPrimalTypes(string currentIndex);
    }


    // Use a data contract as illustrated in the sample below to add composite types to service operations.
    [DataContract]
    public class TextMessage
    {
        [DataMember]
        public string Message { get; set; }
    }
}
