﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;

using Pokedex_Web_Service.DataModel;
using System.Data.Entity;
using System.Data.Linq;

namespace Pokedex_Web_Service
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "Service1" in code, svc and config file together.
    // NOTE: In order to launch WCF Test Client for testing this service, please select Service1.svc or Service1.svc.cs at the Solution Explorer and start debugging.
    public class PokedexRESTJSON : IPokdexRESTJSON
    {
        //database objecT
        pokedexEntities dbcontext = new pokedexEntities();
        typeChangesDBEntities dbcontext_types = new typeChangesDBEntities();

        public string getFlavorText(string currentIndex)
        {
            //assign a variable to hold current index
            int specifiedIndex = Convert.ToInt32(currentIndex);

            //load db
            dbcontext.Pokedexes.Load();

            //query for pokemon at current index
            var flavorQuery =
                from entry in dbcontext.Pokedexes.Local
                where entry.ID == specifiedIndex
                select entry;

            //assign string to hold flavor text from query result (shoudl be one entry)
            string flavorText = flavorQuery.SingleOrDefault().flavorText;

            //return flavor text
            return string.Format(flavorText);
        }

        public string getMaxIndex()
        {
            //load db
            dbcontext.Pokedexes.Load();

            //query for max index (use count)
            var maxQuery =
                from entry in dbcontext.Pokedexes.Local
                select entry;
            //set variable to hold count, converted to string
            string maxIndexCount = Convert.ToString(maxQuery.Count());

            //return var
            return string.Format(maxIndexCount);

        }

        public string getName(string currentIndex)
        {
            //assign a variable to hold current index
            int specifiedIndex = Convert.ToInt32(currentIndex);

            //load db
            dbcontext.Pokedexes.Load();

            //query for pokemon at current index
            var nameQuery =
                from entry in dbcontext.Pokedexes.Local
                where entry.ID == specifiedIndex
                select entry;

            //assign string to hold name from query result (should be one entry)
            string nameText = nameQuery.SingleOrDefault().name;

            //return flavor text
            return string.Format(nameText);
        }

        public string getType1(string currentIndex)
        {
            //assign a variable to hold current index
            int specifiedIndex = Convert.ToInt32(currentIndex);

            //load db
            dbcontext.Pokedexes.Load();

            //query for pokemon at current index
            var type1Query =
                from entry in dbcontext.Pokedexes.Local
                where entry.ID == specifiedIndex
                select entry;

            //assign var to hold type1 !!JUST THE TYPE, NO URL!!
            string type1 = type1Query.SingleOrDefault().type1;

            //return type1
            return string.Format(type1);
        }

        public string getType2(string currentIndex)
        {
            //assign a variable to hold current index
            int specifiedIndex = Convert.ToInt32(currentIndex);

            //load db
            dbcontext.Pokedexes.Load();

            //query for pokemon at current index
            var type2Query =
                from entry in dbcontext.Pokedexes.Local
                where entry.ID == specifiedIndex
                select entry;

            //assign var to hold type1 !!JUST THE TYPE, NO URL!!
            string type2 = type2Query.SingleOrDefault().type2;

            //return type1
            return string.Format(type2);
        }

        public string search(string searchCriteria)
        {
            //load database
            dbcontext.Pokedexes.Load();

            //assign string variable to hold criteria
            string pokemonSearchName = searchCriteria;

            //trim string
            pokemonSearchName = pokemonSearchName.Trim();

            //set string to lowercase
            pokemonSearchName = pokemonSearchName.ToLower();

            //capitalize the first letter
            string firstCapital = Convert.ToString(pokemonSearchName[0]);
            firstCapital = firstCapital.ToUpper();
            pokemonSearchName = firstCapital + Convert.ToString(pokemonSearchName.Substring(1));


            //search query
            var searchQuery =
                from entry in dbcontext.Pokedexes.Local
                where entry.name.Trim() == pokemonSearchName
                select entry;

            //if-else check for query results
            if (searchQuery.Count() != 0)
            {
                return Convert.ToString(searchQuery.SingleOrDefault().ID);
            }
            else
            {
                return "0";
            }
        }

        public List<string> type1Query(string selectedType)
        {
            //load db
            dbcontext.Pokedexes.Load();

            //string object to house selectedType
            string typeForQuery = selectedType;

            //list object to house results
            List<string> resultList = new List<string>();

            //query
            var typeQuery =
                from entry in dbcontext.Pokedexes.Local
                where (entry.type1.Trim() == typeForQuery) || (entry.type2.Trim() == typeForQuery)
                select entry;

            //loop to add entry names to list
            foreach (var entry in typeQuery)
            {
                resultList.Add(entry.name);
            }
            if (resultList.Count == 0)
            {
                List<string> testString = new List<string>();
                testString.Add("1");
                testString.Add("2");
                testString.Add("3");
                return testString;
            }
            else
            {
                return resultList;
            }
        }

        public string getMegaTypes(string currentIndex)
        {
            //PROBLEM IS WITH NEW DATABASE I THINK
            //assign a variable to hold current index
            int specifiedIndex = Convert.ToInt32(currentIndex);

            //load db
            #region Pokedexes db
            dbcontext.Pokedexes.Load();

            //query for pokemon at current index
            var megaTypeQuery =
                from entry in dbcontext.Pokedexes.Local
                where entry.ID == specifiedIndex
                select entry;

            //assign string to hold name from query result (should be one entry)
            string megaTypes = megaTypeQuery.SingleOrDefault().type1;
            #endregion
            //return flavor text
            return string.Format(megaTypes);

        }

        public string getMegaXTypes(string currentIndex)
        {
            return "mega x type";
        }

        public string getMegaYTypes(string currentIndex)
        {
            return "mega y types";
        }

        public string getPrimalTypes(string currentIndex)
        {
            return "primal types";
        }
    }
}
